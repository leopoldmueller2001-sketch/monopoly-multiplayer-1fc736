# Monopoly Realtime Arena – Ausbauplan

1. **Spieloberfläche und Orientierung (umgesetzt):** Originalprojekt vollständig übernommen; bestehendes Gold-/Dunkeldesign, alle Grafiken und Spielfunktionen erhalten. Startseite um zwei umschaltbare Grafikvorschauen und eine Spielstart-Anleitung ergänzt. Profil und Raumeinstieg deutsch beschriftet; Kopierfehler in der Lobby sichtbar gemacht. Vorschauen verändern weder Brettregeln noch die bestehende Brettauswahl.
2. **Bestandsaufnahme und Regelkorrekturen:** Bestehende Engine und Tests fachlich prüfen. Kleine und große Brettvariante ausdrücklich den jeweiligen Modi zuordnen; derzeit sind Grafikdateien und 2D-/3D-Komponenten vorhanden, eine separate Regellogik für beide Größen ist noch zu bestätigen. Gefängnis, Karten, Bankrott und Handel mit Regressionstests absichern.
3. **Verlässliche Räume bis 20 Spieler:** Bestehende Netlify-Datenbankanbindung, Sitzungssicherheit und atomare Spielaktionen prüfen und härten. Gleichzeitige Beitritte, volle Räume, Wiederverbindung und Zustandsrevisionen unter Last testen. Einladungen und Übernahme des Hosts bei Ausfällen absichern.
4. **Strategische Bots:** Schwierigkeitsstufen und nachvollziehbare Entscheidungen für Käufe, Liquiditätsreserve, Bauen, Hypotheken und Handel entwickeln. Deterministische Simulationen mit verschiedenen Spielerzahlen und beiden Brettern ergänzen.
5. **Abwechslung und Balance:** Auktionen, optionale Ereignisse, Missionen, Belohnungen und Gebäude-Upgrades als klar abgegrenzte Erweiterungen umsetzen. Aufholmechanismen und ein zeitlich begrenztes Spielende durch Simulationen abstimmen; bestehende Modi erhalten.
6. **Erfolge und Ranglisten:** Bestehende Rangliste prüfen und um nachvollziehbare Ergebnisse, Erfolge und Schutz gegen manipulierte Ergebnisse ergänzen.
7. **Freigabe und Gesamtarchiv:** Regeltests, Bot-Simulationen, Browserprüfungen beider Brettvarianten und Lastprüfungen mit 20 Spielern durchführen. Typecheck und Build in der Pipeline auswerten. Neues vollständiges ZIP und detaillierten Prüfbericht bereitstellen.

Jeder Meilenstein erhält eigene überprüfbare Abnahmekriterien. Keine Originaldateien, Grafiken, Texturen, Modi oder Funktionen löschen. Änderungen gezielt ergänzen; Backend und Spiellogik werden in dieser Oberflächenetappe nicht umgebaut.


## Umgesetztes Brett- und Handelsupgrade (5. November 2026)

Die Lobby erhielt die Auswahl 40/80/120 Felder. Die Engine, gespeicherte Räume, Käufe, Farbgruppen, Gebäude, Hypotheken, Handel, Bot-Ausbau und Vermögensberechnung wurden um die zusätzlichen Stadtviertel ergänzt. Die Varianten erhielten 1.500/3.000/4.500 Startgeld, 200/400/600 LOS-Bonus und 1/2/3 reguläre Würfe. Klassische Ansichten und Originaldaten blieben erhalten. Große Bretter erhielten eine zusätzliche flache bzw. CSS-perspektivische Ansicht mit Zoom, Übersicht, Figurenbewegung und Kamerafokus. Das Handelsmenü erhielt Partnersuche, sichtbare Hypotheken und Geldvorschau.

Abnahme: 40 automatisierte Tests und Typecheck bestanden. Deterministische Simulationen liefen auf jedem Brett mit 20 Bots für bis zu 1.600 Engine-Aktionen und prüften gültige Positionen, Käufe und gespeicherte Zustände. Statische React-Render-Prüfungen für Lobby, große Bretter, Besitzverwaltung, Handel und HUD bestanden mit simuliertem Browser-Standort. Diese Prüfungen ersetzten keine Browser-Interaktion und keinen Netzwerk-Lasttest. Kein lokaler Build wurde ausgeführt.

Nächste Schritte blieben echte Browserprüfungen auf Desktop und Mobilgeräten, parallele Raumanfragen mit 20 echten Clients und menschliche Balance-Runden. Die weitere Umsetzung der langfristigen Meilensteine (Bot-Schwierigkeitsstufen, neue Ereignisse/Missionen und Erfolge) blieb offen. Bereits angewandte Datenbankmigrationen wurden nicht verändert; die Erweiterung nutzte die bestehenden gespeicherten Raumzustände.
