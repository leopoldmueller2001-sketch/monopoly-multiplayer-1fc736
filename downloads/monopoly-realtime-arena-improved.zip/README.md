# Monopoly Realtime Arena

Bestehendes React-/TypeScript-Multiplayer-Brettspiel mit Lobby, Bots, Handel, Rangliste und 2D-/3D-Ansichten. Die Startseite ergänzt den vorhandenen Gold-/Dunkelstil um Brettgrafik-Vorschauen, deutsche Einstiegstexte und eine kurze Anleitung. Beide Vorschauen sind Präsentationen bestehender Assets, keine neue Modusumschaltung.

Verwendet werden Vite, React, Tailwind CSS, Three.js, Netlify Functions und die bereits enthaltene Netlify-Database-/Drizzle-Anbindung.

## Lokal arbeiten

Abhängigkeiten mit `npm install` installieren. Mit `netlify dev --port 8889` die Anwendung einschließlich Funktions-Emulation starten. Die bestehende Datenbankkonfiguration benötigt eine mit dem Netlify-Projekt verknüpfte Umgebung. Keine Zugangsdaten in Dateien eintragen.

Vorhandene Prüfskripte: `npm test`, `npm run lint` (Typecheck), `npm run build`. In dieser Änderung wurden keine Tests, Typechecks oder Builds ausgeführt; die Bereitstellungspipeline übernimmt die Build-Prüfung.

## Weiterentwicklung

[PLAN.md](PLAN.md) beschreibt die nächsten Etappen für Regeln beider Bretter, sichere Mehrspieler-Räume, Bot-Strategien, Balance und neue Spielfunktionen. Der aktuelle Stand enthält die verbesserte Oberfläche und die unveränderte bestehende Spiellogik. Die umfassende Funktionserweiterung und deren Qualitätssicherung stehen noch aus.

Das Originalarchiv bleibt unter `.netlify/assets/` erhalten. `downloads/monopoly-realtime-arena-improved.zip` enthält alle ursprünglichen Projektdateien an ihren relativen Pfaden sowie die Ergänzungen. Archiv- und Dateivergleiche sind in `.netlify/results.md` dokumentiert.

## Reparatur der Migrationskonfiguration

`drizzle.config.ts` verwendet einen reinen Typimport von `Config` anstelle eines Laufzeitimports von `defineConfig`. Dadurch benötigt das Einlesen der Konfiguration keine lokal auflösbare `drizzle-kit`-Installation. Die bereits deklarierten Beta-Abhängigkeiten, das Schema und der Migrationspfad bleiben erhalten. Die automatische Pipeline führt die Migrationsgenerierung aus; sie wurde bei dieser Reparatur nicht lokal gestartet.

## Abhängigkeiten bei CLI-Deploys

Der konfigurierte Deploy-Befehl führt vor dem Vite-Build `bun install --frozen-lockfile` aus. Damit werden die im bestehenden Bun-Lockfile festgelegten Abhängigkeiten auch dann installiert, wenn der CLI-Deploy keine vorherige Installationsphase ausgeführt hat. Das behebt die Ursache von `vite: command not found`, ohne Paketversionen oder das Lockfile zu verändern. Der Build selbst wurde bei dieser Reparatur nicht lokal ausgeführt.
